package me.saltedfish.autoaccept

import net.mamoe.mirai.console.data.AutoSavePluginConfig
import net.mamoe.mirai.console.data.ValueDescription
import net.mamoe.mirai.console.data.value

object PluginConfig : AutoSavePluginConfig("Config") {
    @ValueDescription("自动同意新好友请求")
    var newFriendRequestEnabled: Boolean by value(true)
    @ValueDescription("自动同意加群请求")
    var joinGroupRequestEnabled: Boolean by value(true)
}