# mirai-console-plugin-template

[Mirai Console](https://github.com/mamoe/mirai-console) 插件模板, 使用 Kotlin + Gradle.

[如何使用](https://github.com/project-mirai/how-to-use-plugin-template)
