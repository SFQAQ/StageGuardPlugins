package me.saltedfish.greeting

import net.mamoe.mirai.Bot
import net.mamoe.mirai.console.command.CommandManager.INSTANCE.register
import net.mamoe.mirai.console.command.CommandSender
import net.mamoe.mirai.console.command.CompositeCommand
import net.mamoe.mirai.console.plugin.jvm.JvmPluginDescription
import net.mamoe.mirai.console.plugin.jvm.KotlinPlugin
import net.mamoe.mirai.console.util.ConsoleExperimentalApi
import net.mamoe.mirai.event.GlobalEventChannel
import net.mamoe.mirai.event.events.BotOnlineEvent
import net.mamoe.mirai.utils.info

object PluginMain : KotlinPlugin(
    JvmPluginDescription(
        id = "me.saltedfish.greeting",
        name = "ScheduledGreeting",
        version = "1.0"
    )
) {
    lateinit var targetBotInstance: Bot
    @ConsoleExperimentalApi
    override fun onEnable() {
        PluginConfig.reload()
        GlobalCommand.register()
        logger.info { "插件已加载，启用状态 ${PluginConfig.enabled}" }
        logger.info { "正在等待机器人 ${PluginConfig.qq} 上线..." }
        GlobalEventChannel.filter {
            it is BotOnlineEvent && it.bot.id == PluginConfig.qq
        }.subscribeOnce<BotOnlineEvent> {
            targetBotInstance = bot
            if(PluginConfig.enabled) GreetingJobManager.initJobs()
            logger.info { "机器人 ${PluginConfig.qq} 已上线，定时问候已启用" }
        }
    }
}

@ConsoleExperimentalApi
@Suppress("unused", "RedundantSuspendModifier")
object GlobalCommand : CompositeCommand(
    PluginMain, "greeting", "管理定时问候属性"
) {
    @SubCommand
    @Description("全局开关")
    suspend fun CommandSender.enabled(@Name("开关") status: Boolean) {
        PluginConfig.enabled = status.also {
            if(it) {
                GreetingJobManager.initJobs()
            } else {
                GreetingJobManager.stopAllJobs()
            }
        }
    }

    @SubCommand
    @Description("添加一个启用问候的群")
    suspend fun CommandSender.addGroup(@Name("群号") group: Long) {
        PluginConfig.enabledGroups.run {
            if(contains(group)) {
                PluginMain.logger.warning("群 $group 已经存在，无需再次添加。")
            } else {
                add(group)
                PluginMain.logger.info("群 $group 已经启用定时问候。")
            }
        }
    }

    @SubCommand
    @Description("删除一个启用问候的群")
    suspend fun CommandSender.removeGroup(@Name("群号") group: Long) {
        PluginConfig.enabledGroups.run {
            if(contains(group)) {
                PluginMain.logger.info("群 $group 已禁用定时问候。")
            } else {
                PluginMain.logger.warning("群 $group 不存在。")
            }
        }
    }

    @SubCommand
    @Description("添加一个标签")
    suspend fun CommandSender.addTag(@Name("名称") name: String, @Name("时间点") time: String) {
        PluginConfig.greetingTime.run {
            if(containsKey(name)) {
                PluginMain.logger.warning("标签 $name 已经存在，请换个名称或删除这个标签后再添加。")
            } else if(!GreetingJobManager.TIME_PATTERN.matches(time)) {
                PluginMain.logger.warning("时间格式有误，请检查。")
            } else {
                put(name, time)
                GreetingJobManager.startJob(name)
                PluginMain.logger.info("标签 $name 已添加，请为这个标签添加提示语。")
            }
        }
    }

    @SubCommand
    @Description("移除一个标签")
    suspend fun CommandSender.removeTag(@Name("名称") name: String) {
        PluginConfig.greetingTime.run {
            if(containsKey(name)) {
                remove(name)
                PluginConfig.greetingTips.remove(name)
                GreetingJobManager.stopJob(name)
                PluginMain.logger.info("标签 $name 已移除。")
            } else {
                PluginMain.logger.warning("标签 $name 不存在，无法移除这个标签。")
            }
        }
    }

    @SubCommand
    @Description("添加一个标签的问候语")
    suspend fun CommandSender.addGreeting(@Name("标签名称") name: String, @Name("问候语") greeting: String) {
        PluginConfig.greetingTips.run {
            if(PluginConfig.greetingTime.containsKey(name)) {
                if(containsKey(name)) {
                    get(name)!!.add(greeting)
                } else put(name, mutableListOf(greeting))
                PluginMain.logger.info("添加成功。")
            } else {
                PluginMain.logger.warning("标签 $name 不存在，无法为这个标签添加提示语。")
            }
        }
    }
}