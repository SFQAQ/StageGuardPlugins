package me.saltedfish.autoaccept

import net.mamoe.mirai.console.command.CommandManager.INSTANCE.register
import net.mamoe.mirai.console.command.CommandSender
import net.mamoe.mirai.console.command.CompositeCommand
import net.mamoe.mirai.console.plugin.jvm.JvmPluginDescription
import net.mamoe.mirai.console.plugin.jvm.KotlinPlugin
import net.mamoe.mirai.console.util.ConsoleExperimentalApi
import net.mamoe.mirai.contact.Group
import net.mamoe.mirai.contact.MemberPermission
import net.mamoe.mirai.event.GlobalEventChannel
import net.mamoe.mirai.event.events.*
import net.mamoe.mirai.utils.info

object PluginMain : KotlinPlugin(
    JvmPluginDescription(
        id = "me.saltedfish.ndugereply",
        name = "Auto Accept",
        version = "1.0"
    )
) {
    private var isTargetBotOnline: Boolean = false
    @ConsoleExperimentalApi
    override fun onEnable() {
        PluginConfig.reload()
        GlobalCommand.register()
        logger.info { "插件已加载。" }
        GlobalEventChannel.subscribeAlways<NewFriendRequestEvent> {
            if(PluginConfig.newFriendRequestEnabled) {
                accept()
                logger.info("已自动同意新好友请求：$fromNick($fromId)")
            }
        }
        GlobalEventChannel.subscribeAlways<MemberJoinRequestEvent> {
            if(PluginConfig.joinGroupRequestEnabled) {
                if(group?.botPermission != MemberPermission.MEMBER) {
                    accept()
                    logger.info("已自动同意加群请求：$fromNick($fromId) 加入到 $groupName($groupId)")
                }

            }
        }
    }

}

@ConsoleExperimentalApi
@Suppress("unused", "RedundantSuspendModifier")
object GlobalCommand : CompositeCommand(
    PluginMain, "autoaccept", "管理自动同意好友请求和加群请求"
) {
    @SubCommand
    @Description("是否开启自动同意新好友请求")
    suspend fun CommandSender.friend(@Name("开关") status: Boolean) {
        PluginConfig.newFriendRequestEnabled = status
        PluginMain.logger.info("自动同意信号有请求已${if(status) "启用" else "禁用"}。")
    }
    @SubCommand
    @Description("是否开启自动同意加群请求")
    suspend fun CommandSender.group(@Name("开关") status: Boolean) {
        PluginConfig.joinGroupRequestEnabled = status
        PluginMain.logger.info("自动同意加群请求请求已${if(status) "启用" else "禁用"}。")
    }
}