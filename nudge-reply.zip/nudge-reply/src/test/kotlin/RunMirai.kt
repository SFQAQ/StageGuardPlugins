package me.saltedfish.ndugereply

import net.mamoe.mirai.alsoLogin
import net.mamoe.mirai.console.MiraiConsole
import net.mamoe.mirai.console.plugin.PluginManager.INSTANCE.enable
import net.mamoe.mirai.console.plugin.PluginManager.INSTANCE.load
import net.mamoe.mirai.console.terminal.MiraiConsoleTerminalLoader
import net.mamoe.mirai.console.util.ConsoleExperimentalApi

@ConsoleExperimentalApi
suspend fun main() {

    val sequence = mutableListOf(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22)

    val lambda : () -> String = outerScope@ {
        sequence.forEach forEachScope@ {
            if(it == 20) {
                return@outerScope "114514"
            } else if(it % 3 == 0) {
                return@forEachScope
            } else print("$it ")
        }
        println("end")
        "1919810"
    }
    println(lambda.invoke())

    /*MiraiConsoleTerminalLoader.startAsDaemon()

    PluginMain.load()
    PluginMain.enable()

    MiraiConsole.addBot(1, "") {
        fileBasedDeviceInfo()
    }.alsoLogin()

    MiraiConsole.job.join()*/
}