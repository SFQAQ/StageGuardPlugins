package me.saltedfish.groupmsgsender

import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import net.mamoe.mirai.Bot
import net.mamoe.mirai.console.command.CommandManager.INSTANCE.register
import net.mamoe.mirai.console.command.CommandSender
import net.mamoe.mirai.console.command.CompositeCommand
import net.mamoe.mirai.console.plugin.jvm.JvmPluginDescription
import net.mamoe.mirai.console.plugin.jvm.KotlinPlugin
import net.mamoe.mirai.console.util.ConsoleExperimentalApi
import net.mamoe.mirai.contact.Group
import net.mamoe.mirai.event.GlobalEventChannel
import net.mamoe.mirai.event.events.*
import net.mamoe.mirai.message.code.MiraiCode.deserializeMiraiCode
import net.mamoe.mirai.message.data.PlainText
import net.mamoe.mirai.message.data.firstIsInstanceOrNull
import net.mamoe.mirai.utils.info
import stageguard.sctimetable.utils.cast
import stageguard.sctimetable.utils.finish
import stageguard.sctimetable.utils.interactiveConversation

object PluginMain : KotlinPlugin(
    JvmPluginDescription(
        id = "me.saltedfish.groupmsgsender",
        name = "Group Message Sender",
        version = "1.0"
    )
) {
    private var isTargetBotOnline: Boolean = false
    @ConsoleExperimentalApi
    override fun onEnable() {
        PluginConfig.reload()
        GlobalCommand.register()
        logger.info { "插件已加载。" }
        logger.info { "正在等待机器人 ${PluginConfig.qq} 上线..." }
        GlobalEventChannel.filter {
            it is BotOnlineEvent && it.bot.id == PluginConfig.qq
        }.subscribeOnce<BotOnlineEvent> {
            logger.info { "机器人 ${PluginConfig.qq} 已上线。" }
            isTargetBotOnline = true
        }
        GlobalEventChannel.subscribeAlways<FriendMessageEvent> {
            if(isTargetBotOnline && it.bot.id == PluginConfig.qq) {
                sendMessage(it.bot, this)
            }
        }
        GlobalEventChannel.subscribeAlways<GroupTempMessageEvent> {
            if(isTargetBotOnline && it.bot.id == PluginConfig.qq) {
                sendMessage(it.bot, this)
            }
        }
    }

    private suspend inline fun <E : MessageEvent> sendMessage(bot: Bot, event: E) {
        val text = event.message.firstIsInstanceOrNull<PlainText>()?.content
        val regex = Regex("(?:${PluginConfig.prefix})\\s(\\*|(?:\\d)+)\\s(.+)")

        if(!(text != null && regex.matches(text))) return
        if(event.sender.id !in PluginConfig.operators) {
            event.sender.sendMessage(
                PluginConfig.tips["denied"] ?: "发送失败，你没有控制机器人发送公告的权限，请联系机器人主人。"
            )
            return
        }

        val matchedGroups = regex.find(text)!!.groupValues
        val groups = mutableListOf<Group>()
        if(matchedGroups[1] == "*") {
            bot.groups.forEach { groups.add(it) }
        } else {
            val group = bot.groups[matchedGroups[1].toLong()]
            if(group == null) {
                event.sender.sendMessage(
                    (PluginConfig.tips["groupNotExist"] ?: "群 {group} 不存在！").replace("{group}", matchedGroups[1])
                )
                return
            }
            groups.add(group)
        }
        event.interactiveConversation {
            send(
                (PluginConfig.tips["confirm"] ?: "将要给以下群发送公告：\n{groups}\n内容为：{content}\n确认要执行操作吗？\n发送“确认”来执行操作。")
                    .replace("{groups}", groups.joinToString("\n") { "${it.name}(${it.id})" })
                    .replace("{content}", matchedGroups[2])
            )
            select {
                "确认" { collect("confirm", true) }
                default { collect("confirm", false) }
            }
        }.finish {
            if(it["confirm"].cast()) {
                groups.forEach { group ->
                    launch {
                        delay((Math.random() * PluginConfig.delayMax).toLong())
                        group.sendMessage(matchedGroups[2].deserializeMiraiCode())
                    }
                }
            } else {
                event.sender.sendMessage(PluginConfig.tips["cancel"] ?: "取消发送。")
            }
        }
    }
}

@ConsoleExperimentalApi
@Suppress("unused", "RedundantSuspendModifier")
object GlobalCommand : CompositeCommand(
    PluginMain, "msgsender", "管理定时问候属性"
) {
    @SubCommand
    @Description("设置最大随机延迟毫秒数")
    suspend fun CommandSender.delayMax(@Name("最大毫秒") max: Long) {
        PluginConfig.delayMax = max
    }
    @SubCommand
    @Description("设置前缀词")
    suspend fun CommandSender.prefix(@Name("前缀词") prefix: String) {
        PluginConfig.prefix = prefix
    }
    @SubCommand
    @Description("添加一个人的使用权限")
    suspend fun CommandSender.addOp(@Name("QQ号") qq: Long) {
        if(qq !in PluginConfig.operators) {
            PluginConfig.operators.add(qq)
            PluginMain.logger.info("添加成功。")
        } else {
            PluginMain.logger.warning("用户 $qq 已经授权，无法重复添加。")
        }
    }
    @SubCommand
    @Description("移除一个人的使用权限")
    suspend fun CommandSender.rmOp(@Name("QQ号") qq: Long) {
        if(qq in PluginConfig.operators) {
            PluginConfig.operators.remove(qq)
            PluginMain.logger.info("移除成功。")
        } else {
            PluginMain.logger.warning("用户 $qq 不存在，无法移除。")
        }
    }
}