package me.saltedfish.ndugereply

import net.mamoe.mirai.console.data.AutoSavePluginConfig
import net.mamoe.mirai.console.data.ValueDescription
import net.mamoe.mirai.console.data.value

object PluginConfig : AutoSavePluginConfig("Config") {
    @ValueDescription("插件开关")
    var enabled: Boolean by value(true)
    @ValueDescription("启用的机器人的QQ号")
    val qq: Long by value(123456789L)
    @ValueDescription("为以下群组启用戳一戳回复")
    val groupsEnabled: MutableList<Long> by value(mutableListOf(114514L, 1919810L))
    @ValueDescription("回复语句")
    val replies: MutableList<String> by value(mutableListOf(
        "I was nudged.",
        "Nudge event."
    ))
}