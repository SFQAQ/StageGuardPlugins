package me.saltedfish.greeting

import net.mamoe.mirai.console.data.AutoSavePluginConfig
import net.mamoe.mirai.console.data.ValueDescription
import net.mamoe.mirai.console.data.value

object PluginConfig : AutoSavePluginConfig("GreetingConfig") {
    @ValueDescription("启用QQ号")
    val qq: Long by value(0L)
    @ValueDescription("全局开关，可以在控制台输入指令设置")
    var enabled: Boolean by value(true)
    @ValueDescription("为以下群组启用，这两个是例子，可以删去")
    val enabledGroups: MutableList<Long> by value(mutableListOf(123123123L, 1145141919810L))
    @ValueDescription("标签和提醒时间，标签用于标识这个提醒(随意设置)，时间采用24小时制")
    val greetingTime: MutableMap<String, String> by value(mutableMapOf(
        "Morning" to "7:00",
        "Noon" to "12:00",
        "Night" to "22:00",
    ))
    @ValueDescription("提示语，为对应标签设置不同的提示语\n提示语会随机选取并发送")
    val greetingTips: MutableMap<String, MutableList<String>> by value(mutableMapOf(
        "Morning" to mutableListOf("早安！", "早安啊~ヾ(≧▽≦*)o"),
        "Noon" to mutableListOf("午安！快去恰饭o(≧口≦)o"),
        "Night" to mutableListOf("晚安，祝好梦(つω｀)～", "该睡觉啦！")
    ))
}