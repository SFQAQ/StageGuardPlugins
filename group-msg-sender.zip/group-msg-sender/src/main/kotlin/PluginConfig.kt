package me.saltedfish.groupmsgsender

import net.mamoe.mirai.console.data.AutoSavePluginConfig
import net.mamoe.mirai.console.data.ValueDescription
import net.mamoe.mirai.console.data.value

object PluginConfig : AutoSavePluginConfig("Config") {
    @ValueDescription("启用的机器人的QQ号")
    val qq: Long by value(123456789L)
    @ValueDescription("有权限操作的用户的QQ号，可以为多个人设置权限")
    val operators: MutableList<Long> by value(mutableListOf(114514L, 1919810L))
    @ValueDescription("指令前缀")
    var prefix: String by value("发送公告")
    @ValueDescription("提示信息")
    val tips: MutableMap<String, String> by value(mutableMapOf(
        "denied" to "发送失败，你没有控制机器人发送公告的权限，请联系机器人主人。",
        "groupNotExist" to "群 {group} 不存在！",
        "confirm" to "将要给以下群发送公告：\n{groups}\n内容为：{content}\n确认要执行操作吗？\n发送“确认”来执行操作。",
        "cancel" to "取消发送。"
    ))
    @ValueDescription("随机延迟的最长时间， 单位毫秒")
    var delayMax: Long by value(30000L)
}