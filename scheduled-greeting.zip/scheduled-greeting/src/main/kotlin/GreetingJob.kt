package me.saltedfish.greeting

import kotlinx.coroutines.launch
import org.quartz.*
import org.quartz.impl.StdSchedulerFactory

object GreetingJobManager {
    private val scheduler: Scheduler by lazy {
        StdSchedulerFactory.getDefaultScheduler().also { it.start() }
    }
    val TIME_PATTERN = Regex("(\\d+)[:：](\\d+)")
    private val jobPool: MutableMap<String, JobDetail> = mutableMapOf()

    private fun startJobInternal(name: String, time: String) {
        stopJobInternal(name)
        val parsed = TIME_PATTERN.find(time)?.groupValues
        if(parsed == null) {
            PluginMain.logger.error("Error while parsing timestamp $time")
            return
        }
        jobPool[name] = JobBuilder.newJob(GreetingJob::class.java).apply {
            usingJobData("tag", name)
        }.build().also {
            scheduler.scheduleJob(it, TriggerBuilder.newTrigger().withSchedule(
                CronScheduleBuilder.cronSchedule("0 ${parsed[2]} ${parsed[1]} * * ? ")
            ).build())
        }
    }

    private fun stopJobInternal(name: String, remove: Boolean = true) {
        if(jobPool.containsKey(name)) {
            scheduler.interrupt(jobPool[name]!!.key)
            scheduler.deleteJob(jobPool[name]!!.key)
            if(remove) jobPool.remove(name)
        }
    }

    fun stopAllJobs() {
        jobPool.forEach {
            stopJobInternal(it.key, false)
        }
        jobPool.clear()
    }

    fun startJob(tagName: String) {
        if(PluginConfig.greetingTime.containsKey(tagName)) {
            startJobInternal(tagName, PluginConfig.greetingTime[tagName]!!)
        } else PluginMain.logger.error("Tag $tagName is not found.")
    }

    fun stopJob(tagName: String) {
        stopJobInternal(tagName)
    }

    fun initJobs() {
        PluginConfig.greetingTime.forEach {
            startJobInternal(it.key, it.value)
        }
    }
}

class GreetingJob: InterruptableJob {
    override fun execute(context: JobExecutionContext?) {
        context?.jobDetail?.jobDataMap?.run {
            PluginMain.launch {
                val tag = getString("tag")
                val greetings = PluginConfig.greetingTips[tag]
                if(greetings == null || greetings.count() == 0) {
                    PluginMain.logger.error("No greetings found for tag $tag")
                } else {
                    PluginConfig.enabledGroups.forEach {
                        PluginMain.targetBotInstance.groups[it]?.sendMessage(greetings.random())
                    }
                }
            }
        }
    }
    override fun interrupt() {  }
}