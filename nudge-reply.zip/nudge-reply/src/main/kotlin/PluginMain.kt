package me.saltedfish.ndugereply

import net.mamoe.mirai.Bot
import net.mamoe.mirai.console.command.CommandManager.INSTANCE.register
import net.mamoe.mirai.console.command.CommandSender
import net.mamoe.mirai.console.command.CompositeCommand
import net.mamoe.mirai.console.plugin.jvm.JvmPluginDescription
import net.mamoe.mirai.console.plugin.jvm.KotlinPlugin
import net.mamoe.mirai.console.util.ConsoleExperimentalApi
import net.mamoe.mirai.contact.Group
import net.mamoe.mirai.event.GlobalEventChannel
import net.mamoe.mirai.event.events.*
import net.mamoe.mirai.utils.info

object PluginMain : KotlinPlugin(
    JvmPluginDescription(
        id = "me.saltedfish.ndugereply",
        name = "Nudge Reply",
        version = "1.0.2"
    )
) {
    private var isTargetBotOnline: Boolean = false
    lateinit var targetBotInstance: Bot
    @ConsoleExperimentalApi
    override fun onEnable() {
        PluginConfig.reload()
        GlobalCommand.register()
        logger.info { "插件已加载，启用状态 ${PluginConfig.enabled}" }
        logger.info { "正在等待机器人 ${PluginConfig.qq} 上线..." }
        GlobalEventChannel.filter {
            it is BotOnlineEvent && it.bot.id == PluginConfig.qq
        }.subscribeOnce<BotOnlineEvent> {
            logger.info { "机器人 ${PluginConfig.qq} 已上线。" }
            isTargetBotOnline = true
            targetBotInstance = bot
        }

        GlobalEventChannel.subscribeAlways<NudgeEvent> {
            if(!PluginConfig.enabled) return@subscribeAlways
            if(subject is Group && subject.id in PluginConfig.groupsEnabled && target.id == bot.id) {
                subject.sendMessage(PluginConfig.replies.random())
            }
        }
    }

}

@ConsoleExperimentalApi
@Suppress("unused", "RedundantSuspendModifier")
object GlobalCommand : CompositeCommand(
    PluginMain, "nudge", "管理戳一戳回复属性"
) {
    @SubCommand
    @Description("全局开关")
    suspend fun CommandSender.enabled(@Name("开关") status: Boolean) {
        PluginConfig.enabled = status
        PluginMain.logger.info("戳一戳回复已${if(status) "启用" else "禁用"}。")
    }
    @SubCommand
    @Description("添加启用的群")
    suspend fun CommandSender.addGroup(@Name("群号") qq: Long) {
        if(qq !in PluginConfig.groupsEnabled) {
            PluginConfig.groupsEnabled.add(qq)
            PluginMain.logger.info("添加成功。")
        } else {
            PluginMain.logger.warning("群 $qq 已存在，无法重复添加。")
        }
    }
    @SubCommand
    @Description("移除启用的群")
    suspend fun CommandSender.removeGroup(@Name("群号") qq: Long) {
        if(qq in PluginConfig.groupsEnabled) {
            PluginConfig.groupsEnabled.remove(qq)
            PluginMain.logger.info("移除成功。")
        } else {
            PluginMain.logger.warning("群 $qq 不存在，无法移除。")
        }
    }

    @SubCommand
    @Description("添加一个回复语")
    suspend fun CommandSender.addReply(@Name("回复语") text: String) {
        if(text !in PluginConfig.replies) {
            PluginConfig.replies.add(text)
            PluginMain.logger.info("添加成功。")
        } else {
            PluginMain.logger.warning("回复语 $text 已存在，无法重复添加。")
        }
    }
    @SubCommand
    @Description("删除一个回复语")
    suspend fun CommandSender.removeReply(@Name("回复语") text: String) {
        if(text in PluginConfig.replies) {
            PluginConfig.replies.remove(text)
            PluginMain.logger.info("移除成功。")
        } else {
            PluginMain.logger.warning("群 $text 不存在，无法移除。")
        }
    }
    @SubCommand
    @Description("为所有群组启用（添加所有群组）")
    suspend fun CommandSender.addAllGroups() {
        PluginMain.targetBotInstance.groups.map { it.id }.let {
            PluginConfig.groupsEnabled.addAll(it)
        }
        PluginMain.logger.info("已为所有群组启用。")
    }
}